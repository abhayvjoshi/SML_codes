To run the following code type
python filename.py
if any module is not installed then it will through an error,just install that module
